//
//  CustomTextView.swift
//  CustomNotes
//
//  Created by Alessandro Musto on 3/20/17.
//  Copyright © 2017 Lmusto. All rights reserved.
//

import Foundation
import UIKit

public class ClickableTextView: UITextView {


    var tap:UITapGestureRecognizer!

    override public init(frame: CGRect, textContainer: NSTextContainer?) {
        super.init(frame: frame, textContainer: textContainer)
        setup()
    }

    required public init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        setup()
    }


    func setup(){

        tap = UITapGestureRecognizer(target: self, action: #selector(onTap(_:)))

        self.addGestureRecognizer(tap)
    }

    @objc func onTap(_ sender: UITapGestureRecognizer) {

        let myTextView = sender.view as! UITextView

        var location = sender.location(in: myTextView)
        location.x -= myTextView.textContainerInset.left;
        location.y -= myTextView.textContainerInset.top;
    }
}
