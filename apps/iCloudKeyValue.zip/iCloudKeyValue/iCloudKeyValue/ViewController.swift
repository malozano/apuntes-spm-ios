//
//  ViewController.swift
//  iCloudKeyValue
//
//  Created by Domingo on 10/04/2019.
//  Copyright © 2019 Domingo Gallardo. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var stepper: UIStepper!
    @IBOutlet weak var valorLabel: UILabel!
    
    let store = NSUbiquitousKeyValueStore.default
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.muestra(valor: 0)
    }

    @IBAction func pulsadoStepper(_ sender: UIStepper) {
        let valorPulsado: Int = Int(sender.value)
        self.muestra(valor: valorPulsado)
    }
    
    func muestra(valor: Int) {
        stepper.value = Double(valor)
        valorLabel.text = String(valor)
    }
}
