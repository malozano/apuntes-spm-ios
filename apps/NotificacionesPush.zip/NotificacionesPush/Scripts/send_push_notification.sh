#!/bin/bash

# Development server: api.sandbox.push.apple.com:443
#
# Production server: api.push.apple.com:443

ENDPOINT=https://api.sandbox.push.apple.com:443
URLPATH=/3/device/

# the app bundle id
BUNDLEID=es.ua.mudsdm.NotificacionesPush

# your device token
DEVICETOKEN=1dbd1cdebf20db807b41704b2a9234afafbb498fb8af9537ef247ffc5a584078

URL=$ENDPOINT$URLPATH$DEVICETOKEN

JWT=eyAiYWxnIjogIkVTMjU2IiwgImtpZCI6ICIzU0RENjg1WjdOIiB9.eyAiaXNzIjogIlhVMjNLVVQzTlYiLCAiaWF0IjogMTc0MDEzMTEwMCB9.MEYCIQC1zZJfccud7edhZsRTtStbk9bs0OzDh_MaRvnHD0KwwwIhAM1cMhIPkohmissjIMs4kOCUsbpToKGywrx2fZVdt1qH

curl -v \
  --http2 \
  --header "authorization: bearer $JWT" \
  --header "apns-topic: ${BUNDLEID}" \
  --data '{"aps" : {"alert" : {"title" : "Notificación con saludo", "subtitle" : "Saludos desde la UA", "body" : "¡Pasándolo bien con las notificaciones Push!"}, "badge" : 2}, "mensaje" : "Mensaje custom"}' \
  "${URL}"

#  --header "apns-push-type: background" \
#  --data '{"aps" : {"content-available" : 1}, "mensaje" : "Holaaaa"}' \
#  --data '{"aps" : {"alert" : {"title" : "Qué passa amigo", "subtitle" : "Saludos desde Alicante", "body" : "Aquí está haciendo muy buen tiempo"}, "badge" : 0}}' \
