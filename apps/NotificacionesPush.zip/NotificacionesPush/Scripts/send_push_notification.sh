#!/bin/bash

# Development server: api.sandbox.push.apple.com:443
#
# Production server: api.push.apple.com:443

ENDPOINT=https://api.sandbox.push.apple.com:443
URLPATH=/3/device/

# the app bundle id
BUNDLEID=bundle.id

# your device token
DEVICETOKEN=c8e9b72e1fc61e4fdbb3a3f15a32fe995f930ebab99ea5e4ee25b0e3641a7996

URL=$ENDPOINT$URLPATH$DEVICETOKEN

JWT=eyAiYWxnIjogIkVTMjU2IiwgImtpZCI6ICJXM0g2WjlBNFI0IiB9.eyAiaXNzIjogIjNTOTUyQUdINDYiLCAiaWF0IjogMTY3Njk3NTg1NSB9.MEQCIC2P2cBtv56zM2aJd-UNsbBBoEj2dRVjZjTFyo_t0xYUAiBEbmyDon9SQtAYaRBefg-Ocs_jlGJtHikMKTbvJUFZ-w

curl -v \
  --http2 \
  --header "authorization: bearer $JWT" \
  --header "apns-topic: ${BUNDLEID}" \
  --data '{"aps" : {"alert" : {"title" : "Notificación con saludo", "subtitle" : "Saludos desde la UA", "body" : "¡Pasándolo bien con las notificaciones Push!"}, "badge" : 2}, "mensaje" : "Mensaje custom"}' \
  "${URL}"

#  --header "apns-push-type: background" \
#  --data '{"aps" : {"content-available" : 1}, "mensaje" : "Holaaaa"}' \
#  --data '{"aps" : {"alert" : {"title" : "Qué passa amigo", "subtitle" : "Saludos desde Alicante", "body" : "Aquí está haciendo muy buen tiempo"}, "badge" : 0}}' \
