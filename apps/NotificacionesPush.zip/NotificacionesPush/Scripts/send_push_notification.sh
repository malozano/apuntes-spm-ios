#!/bin/bash

# Development server: api.sandbox.push.apple.com:443
#
# Production server: api.push.apple.com:443

ENDPOINT=https://api.sandbox.push.apple.com:443
URLPATH=/3/device/

# your bundle id
BUNDLEID=bundle.id

# your device token
DEVICETOKEN=a7aece1640f3e3b787f3f88c33523eb1231fcd27ebe3c22170c472b02447af38

URL=$ENDPOINT$URLPATH$DEVICETOKEN

JWT=eyAiYWxnIjogIkVTMjU2IiwgImtpZCI6ICJUWFlYNUFYTFpCIiB9.eyAiaXNzIjogIjNTOTUyQUdINDYiLCAiaWF0IjogMTY0Nzk1MzMzNiB9.MEQCHyNiwZj5sn_GNkw7ruoB9ARtslBx12eiIom5SpeDoAQCIQDm2-kaysAt9g6ci6w4G0titBQ30dFVivdQKf1PABKsJA

curl -v \
  --http2 \
  --header "authorization: bearer $JWT" \
  --header "apns-topic: ${BUNDLEID}" \
  --data '{"aps" : {"alert" : {"title" : "Notificación con saludo", "subtitle" : "Saludos desde la UA", "body" : "¡Pasándolo bien con las notificaciones Push!"}, "badge" : 2}, "mensaje" : "Mensaje custom"}' \
  "${URL}"

#  --header "apns-push-type: background" \
#  --data '{"aps" : {"content-available" : 1}, "mensaje" : "Holaaaa"}' \
#  --data '{"aps" : {"alert" : {"title" : "Qué passa amigo", "subtitle" : "Saludos desde Alicante", "body" : "Aquí está haciendo muy buen tiempo"}, "badge" : 0}}' \
