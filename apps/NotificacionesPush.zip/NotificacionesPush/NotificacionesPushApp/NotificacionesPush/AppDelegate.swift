

import UIKit
import UserNotifications

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate, UNUserNotificationCenterDelegate {
    
    var window: UIWindow?
    
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplicationLaunchOptionsKey: Any]?) -> Bool {
        print("En didFinishLaunchingWithOptions")
        UITabBar.appearance().barTintColor = UIColor.themeGreenColor
        UITabBar.appearance().tintColor = UIColor.white

        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge])
        { (granted, error) in print(granted)}
        application.registerForRemoteNotifications()
        UNUserNotificationCenter.current().delegate = self
        return true
    }

    // MARK: Helpers
    func createNewNewsItem(_ notificationDictionary:[String: AnyObject]) {
        if let news = notificationDictionary["alert"] as? String {
            let date = Date()
            
            let newsItem = NewsItem(title: news, date: date)
            let newsStore = NewsStore.sharedStore
            newsStore.addItem(newsItem)
            
            NotificationCenter.default.post(name: Notification.Name(rawValue: NewsFeedTableViewController.RefreshNewsFeedNotification), object: self)
        }
    }
    
    func application(_ application: UIApplication, didRegisterForRemoteNotificationsWithDeviceToken deviceToken: Data) {
        var token = ""
        for i in 0..<deviceToken.count {
            token = token + String(format: "%02.2hhx", arguments: [deviceToken[i]])
        }
        print(token)
    }
    
    func application(_ application: UIApplication, didReceiveRemoteNotification userInfo: [AnyHashable : Any], fetchCompletionHandler completionHandler: @escaping (UIBackgroundFetchResult) -> Void) {
        print("Recibida notificación remota en background")
        // Obtenemos la información de la notifiación y actualizamos la app
        let aps = userInfo["aps"] as! [String: AnyObject]
        createNewNewsItem(aps)
        completionHandler(UIBackgroundFetchResult.newData)
    }
    
    func userNotificationCenter(_ center: UNUserNotificationCenter, willPresent notification: UNNotification,
                                withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {
        print("Recibida notificación primer plano")
        let aps = notification.request.content.userInfo["aps"] as! [String: AnyObject]
        createNewNewsItem(aps)
        // No mostramos la notificación
        completionHandler([])
    }
    
    func userNotificationCenter(_ center: UNUserNotificationCenter, didReceive response: UNNotificationResponse, withCompletionHandler completionHandler: @escaping () -> Void) {
        print("Usuario ha pulsado una notificación")
        let aps = response.notification.request.content.userInfo["aps"] as! [String: AnyObject]
        if let contentAvailable = aps["content-available"] as? Int , contentAvailable == 1 {
            print ("Ya se ha actualizado la noticia al ser un background update")
        }
        else {
            createNewNewsItem(aps)
        }
        completionHandler()
    }
}

