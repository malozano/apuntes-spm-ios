

import UIKit
import UserNotifications

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate, UNUserNotificationCenterDelegate {
    
    var window: UIWindow?
    
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        print("En didFinishLaunchingWithOptions")
        UITabBar.appearance().barTintColor = UIColor.themeGreenColor
        UITabBar.appearance().tintColor = UIColor.white

        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge])
        { (granted, error) in print(granted)}
        application.registerForRemoteNotifications()
        UNUserNotificationCenter.current().delegate = self
        return true
    }

    func application(_ application: UIApplication, didRegisterForRemoteNotificationsWithDeviceToken deviceToken: Data) {
        var token = "Device Token: "
        for i in 0..<deviceToken.count {
            token = token + String(format: "%02.2hhx", arguments: [deviceToken[i]])
        }
        print(token)
    }
    
    func userNotificationCenter(_ center: UNUserNotificationCenter, willPresent notification: UNNotification, withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {
        print("Recibida notificación primer plano")
        let userInfo = notification.request.content.userInfo
        createNewNewsItem(text: message(userInfo: userInfo) +
                          " (userNotificationCenter willPresent)")
        // No mostramos la notificación
        completionHandler([])
    }
    
    func userNotificationCenter(_ center: UNUserNotificationCenter, didReceive response: UNNotificationResponse, withCompletionHandler completionHandler: @escaping () -> Void) {
        print("Usuario ha pulsado una notificación")
        let userInfo = response.notification.request.content.userInfo
        createNewNewsItem(text: message(userInfo: userInfo) + " (userNotificationCenter didReceive)")
        completionHandler()
    }
    
    func application(_ application: UIApplication, didReceiveRemoteNotification userInfo: [AnyHashable : Any], fetchCompletionHandler completionHandler: @escaping (UIBackgroundFetchResult) -> Void) {
        print("Recibida notificación remota en background")
        createNewNewsItem(text: message(userInfo: userInfo) +
                          " (UIApplication didReceiveRemoteNotification)")
        completionHandler(UIBackgroundFetchResult.newData)
    }
    
    func message(userInfo: [AnyHashable : Any]) -> String {
        // Buscamos el mensaje en las claves custom
        if let message = userInfo["mensaje"] as? String {
            return message
        } else {
            // Cogemos como mensaje el valor o el título de la alerta
            let aps = userInfo["aps"] as! [String: AnyObject]
            if let message = aps["alert"] as? String {
                return message
            } else if let dic = aps["alert"] as? [String: AnyObject] {
                return dic["title"] as! String
            } else {
                return ""
            }
        }
    }
    
    func createNewNewsItem(text: String) {
        let date = Date()
        let newsItem = NewsItem(title: text, date: date)
        let newsStore = NewsStore.sharedStore
        newsStore.addItem(newsItem)
        
        NotificationCenter.default.post(name: Notification.Name(rawValue: NewsFeedTableViewController.RefreshNewsFeedNotification), object: self)
    }
}

